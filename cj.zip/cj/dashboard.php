<?php include 'header.php';?>
    <div class="checkout_area section-padding-80">
        <div class="container">
            <div class="row">

                <div class="col-12 col-md-6">
                    <div class="checkout_details_area mt-50 clearfix">

                        <div class="cart-page-heading mb-30">
                            <h5>Dashboard</h5>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="last_name">Atur Barang</label>
                                <a href="#"><h6>Tambah Barang</h6></a>
                                <a href="#"><h6>Lihat Barang</h6></a>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="last_name">Profil</label>
                                <a href="#"><h6>Ubah Foto</h6></a>
                                <a href="#"><h6>Ubah Profil</h6></a>
                                <a href="#"><h6>Ubah Nama Toko</h6></a>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="last_name">Keuangan</label>
                                <a href="#"><h6>Tambah Voucher</h6></a>
                                <a href="#"><h6>Diskon Barang</h6></a>
                                <a href="#"><h6>Detail Pendapatan</h6></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php include 'footer.php';?>